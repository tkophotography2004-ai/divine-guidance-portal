# Admin Setup Guide - Divine Talks with Zahrah Imani

## Welcome Tina! 🌟

This guide will help you get your Divine Talks platform up and running in just a few steps.

## Prerequisites

1. **Railway Account**: Sign up at [railway.app](https://railway.app) (free)
2. **Stripe Account**: Set up at [stripe.com](https://stripe.com) (for payments)
3. **Hedra AI Account**: Your API key is already configured
4. **Domain (Optional)**: You can use Railway's free domain or connect your own

## Step 1: Deploy to Railway 🚀

### Option A: Direct Upload (Recommended)
1. Download the complete project ZIP file
2. Go to [railway.app](https://railway.app)
3. Click "New Project" → "Deploy from GitHub repo" → "Deploy Now"
4. Upload your ZIP file
5. Railway will automatically detect it's a Flask app

### Option B: GitHub Integration
1. Upload the project to a GitHub repository
2. Connect Railway to your GitHub account
3. Select your repository and deploy

## Step 2: Add Database 🗄️

1. In your Railway project dashboard
2. Click "+ New Service"
3. Select "PostgreSQL"
4. Railway will automatically set the `DATABASE_URL` environment variable

## Step 3: Configure Environment Variables 🔧

In Railway, go to your app → Variables tab and add:

```
FLASK_SECRET_KEY=generate-a-long-random-string-here
STRIPE_PUBLISHABLE_KEY=pk_test_51RwwO6HuGENKoTvwnw0bX1QsJjlIQKRWKDtvUgxFNMUYcMmgsw1wfvLa5T8LplCSUUB9t2k
STRIPE_SECRET_KEY=sk_test_51RwwO6HuGENKoTvwyYhDkwkDYUNOnFjpTPHj15lLaamL8qGgLsKe7DEjgnMiW02tVaqVT1B5k4sbvWQcMOJAkWlg00DzFyQVSr
HEDRA_API_KEY=sk_hedra_WV-NTO8Wa_KB49KTNB3OcGfulae5hecphe3N0e3Vnkpmi79z-GJQVPlaNkupimt6
```

**Important**: Generate a strong secret key at [passwordsgenerator.net](https://passwordsgenerator.net)

## Step 4: First Login & Setup 👤

1. Once deployed, visit your Railway URL (e.g., `yourapp.railway.app`)
2. Go to `/admin` 
3. Login with:
   - **Username**: `tina_admin`
   - **Password**: `DivineTalks2024!`
4. **IMMEDIATELY** change your password in settings

## Step 5: Customize Your Settings ⚙️

In the admin dashboard:

### Update Your Schedule
- Current: Weekdays 5:30-10pm, Weekends 8am-10pm CST
- Modify in "Manage Availability" if needed

### Adjust Pricing
- Quick Insight: $17 (15 min)
- Deep Reading: $97 (45 min) 
- Soul Transformation: $297 (90 min)

### Test Stripe Integration
1. Use Stripe test card: `4242 4242 4242 4242`
2. Any future date and 3-digit CVC
3. Complete a test booking to verify payment flow

## Step 6: Go Live Checklist ✅

### Before Launch
- [ ] Test all session types and payments
- [ ] Verify Hedra avatar connection works
- [ ] Check mobile responsiveness on your phone
- [ ] Test admin dashboard functionality
- [ ] Ensure TikTok links work correctly

### Launch Day
- [ ] Switch Stripe to live mode (in Stripe dashboard)
- [ ] Update environment variables with live Stripe keys
- [ ] Share your Railway URL on TikTok
- [ ] Monitor first few bookings closely

### Post-Launch
- [ ] Set up custom domain (optional)
- [ ] Monitor revenue in admin dashboard
- [ ] Respond to customer emails promptly
- [ ] Create TikTok content about your platform

## Daily Operations 📅

### Morning Routine (5 minutes)
1. Check admin dashboard for today's bookings
2. Verify any new payments processed
3. Review customer messages/special requests

### Before Sessions
1. Test your internet connection
2. Ensure good lighting for avatar
3. Review client's special requests
4. Join session room 5 minutes early

### After Sessions
1. Add any notes in the admin panel
2. Follow up with clients if needed
3. Update availability if schedule changes

## Troubleshooting 🔧

### Common Issues

**"500 Internal Server Error"**
- Check environment variables are set correctly
- Verify database connection in Railway logs

**"Payment Failed"**
- Ensure Stripe keys are correct
- Check Stripe dashboard for error details

**"Avatar Won't Load"**
- Verify Hedra API key is correct
- Check browser permissions for camera/microphone

**"Sessions Not Showing"**
- Confirm timezone settings (CST)
- Check if slots are within your available hours

### Getting Help
- **Technical Issues**: tkophotography2004@gmail.com
- **Railway Support**: [railway.app/help](https://railway.app/help)
- **Stripe Support**: [stripe.com/support](https://stripe.com/support)

## Revenue Tracking 💰

Your admin dashboard shows:
- **Daily Revenue**: Today's earnings
- **Weekly Revenue**: This week's total  
- **Monthly Revenue**: Current month earnings
- **All-Time Revenue**: Total lifetime earnings

### Monthly Goals
- **Month 1**: $500-1,000 (getting established)
- **Month 2**: $1,500-2,500 (building audience)
- **Month 3+**: $3,000+ (scaling up)

## Marketing Tips 📱

### TikTok Strategy
1. **Show Behind-the-Scenes**: Your setup process
2. **Client Testimonials**: Success stories (with permission)
3. **Mini-Readings**: Free insights to attract followers
4. **Platform Tours**: Show how easy booking is

### Content Ideas
- "Day in the life of a spiritual guide"
- "Technology meets spirituality" 
- "Book your session in 60 seconds"
- "Client transformation stories"

## Security Best Practices 🔐

1. **Change Default Password**: First thing after login
2. **Use Strong Passwords**: Include numbers, symbols, caps
3. **Regular Backups**: Railway handles this automatically
4. **Monitor Access**: Check admin logs regularly
5. **Keep API Keys Secret**: Never share in videos/posts

## Success Metrics 📊

Track these weekly:
- **New Customers**: First-time bookers
- **Repeat Customers**: Return clients (goal: 30%+)
- **Average Session Value**: Aim for $80+ average
- **TikTok Followers**: Grow your audience
- **Conversion Rate**: Visitors who book (goal: 3-5%)

## Scaling Your Business 📈

### Phase 1: Foundation (Months 1-2)
- Perfect your session delivery
- Build TikTok following to 10K+
- Establish consistent schedule
- Collect testimonials

### Phase 2: Growth (Months 3-6)  
- Add group session options
- Create digital products (meditation tracks)
- Partner with other spiritual influencers
- Launch referral program

### Phase 3: Expansion (Months 6+)
- Train other spiritual guides
- Develop course/coaching programs
- Write spiritual guidance book
- Explore additional revenue streams

---

## Quick Reference Card 📋

**Your Admin URL**: `yourapp.railway.app/admin`
**Username**: `tina_admin`  
**Password**: `DivineTalks2024!` ⚠️ CHANGE THIS!

**Support Email**: tkophotography2004@gmail.com
**TikTok**: @tkotalks
**Stripe Dashboard**: [dashboard.stripe.com](https://dashboard.stripe.com)

---

**Remember**: You've got this, Tina! Your spiritual gifts combined with this technology will help so many people. Start small, stay consistent, and watch your divine business flourish! ✨

*Any questions? Don't hesitate to reach out. I'm here to help you succeed!*
